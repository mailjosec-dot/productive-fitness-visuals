# Productive Fitness Visual Style Guide v1

## Core Principle
Every sketch should feel like it came from the same notebook: black-marker, simple, consistent, and book-ready.

## Character System
- Circular head
- Two dot eyes
- No nose
- Simple stick limbs
- Consistent proportions
- Only five expressions: neutral, happy, frustrated, thinking, celebrating

## Line System
- Black marker only
- Heavy line for titles
- Medium line for main objects
- Light line for details
- No color, gradients, realistic rendering, or textured backgrounds

## Label System
- ALL CAPS
- Handwritten feel
- 1–4 words per label whenever possible
- No long sentences inside diagrams

## Layout System
Full-page sketches should follow:
1. Title at top
2. Main visual in center
3. Outcome or key takeaway at bottom

## Recurring Symbols
- Lightning bolt = execution
- Gear = systems
- Brain = mindset
- Dumbbell = fitness
- Plate = nutrition
- Capsule = supplementation
- Clock = consistency
- Trophy = outcome

## Originality Rules
Do not copy reference sketches, proprietary frameworks, page layouts, icon arrangements, or exact visual metaphors. Use references for style only.
