# AGENTS.md

You are building the Productive Fitness visual asset system.

## Goal
Generate consistent hand-drawn black-marker sketch prompts and production assets for the Productive Fitness manuscript.

## Visual Style
- Black marker doodle style
- Simple stick figures
- Clean educational diagrams
- White or transparent background
- No color
- No realistic illustration
- No shaded backgrounds
- No copied reference layouts
- Presentation/book ready
- Short readable labels only

## Required Process For Each Sketch
1. Read the blueprint row.
2. Identify the core teaching point.
3. Generate 3 original visual metaphors internally.
4. Select the clearest and most book-ready metaphor.
5. Create a final image prompt.
6. Save it as `/prompts/{ID}.md`.
7. Include:
   - ID
   - Title
   - Chapter
   - Purpose
   - Priority
   - Visual metaphor
   - Final image prompt
   - Notes for generation
8. Do not generate repetitive metaphors unless the blueprint explicitly calls for recurring IP.

## Priority
Start with PF-001 through PF-010 before producing chapter-level sketches.

## Originality Guardrail
Reference images are style references only. Do not copy compositions, frameworks, labels, icon arrangements, or proprietary visual metaphors.
