# Prompt Template

Create a clean hand-drawn black-marker sketch illustration with a transparent background.

## Concept
[One-sentence concept summary.]

## Visual Composition
[Describe the full sketch layout, central metaphor, supporting elements, arrows, labels, and final outcome.]

## Key Elements
- [Element 1]
- [Element 2]
- [Element 3]
- [Element 4]

## Style
Minimal black marker doodle, simple stick figures, clean business/fitness sketch, isolated line art, no shading, no color, no background objects, transparent background, high readability, presentation-ready.

## Requirements
Original concept, unique metaphor, not copied from reference images, suitable for books, slides, courses, and professional educational materials.
