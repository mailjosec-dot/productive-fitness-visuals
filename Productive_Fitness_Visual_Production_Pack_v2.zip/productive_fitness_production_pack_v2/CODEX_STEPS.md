# Codex Step-by-Step Instructions

## 1. Create Repository
Create a GitHub repository named `productive-fitness-visuals`.

## 2. Upload Pack
Unzip this production pack into the repository root.

## 3. Confirm Structure
Confirm these folders exist:
- blueprint
- style-guide
- prompts
- images
- approved
- rejected
- scripts

## 4. Connect Codex
Open Codex, connect the repository, and let it read `AGENTS.md`.

## 5. First Codex Task
Paste this task into Codex:

```
Inspect the blueprint spreadsheet and CSV. Create or refine production-ready markdown prompt files for PF-001 through PF-010 only. Follow AGENTS.md and the visual style guide. Do not generate images yet.
```

## 6. Review Prompt Files
Review:
- /prompts/signature-frameworks/PF-001.md
- ...
- /prompts/signature-frameworks/PF-010.md

## 7. Generate Images
Generate images from approved prompts using ChatGPT Images or the OpenAI Images API.

## 8. Review and Sort
Move approved images to `/approved` and rejected images to `/rejected`.

## 9. Update Status
Ask Codex:

```
Update the blueprint CSV and XLSX statuses based on files in /approved and /rejected.
```

## 10. Scale
Only after PF-001 through PF-010 feel visually consistent, continue to INT-01 through C5-07.
