# Productive Fitness Visual Production Pack v2

This repository contains the production pipeline for creating consistent sketch illustrations for the Productive Fitness manuscript.

## Included
- `/blueprint/Productive_Fitness_Visual_Blueprint_v2.xlsx`
- `/blueprint/Productive_Fitness_Visual_Blueprint_v2.csv`
- `/style-guide/Productive_Fitness_Visual_Style_Guide_v1.md`
- `/prompts/PROMPT_TEMPLATE.md`
- `/prompts/signature-frameworks/PF-001.md` through `PF-010.md`
- `AGENTS.md`
- `CODEX_STEPS.md`
- `README.md`
- `/images`, `/approved`, `/rejected`, `/scripts` folders

## Workflow
1. Use Codex to generate and refine prompt files.
2. Generate images in batches using ChatGPT Images or the OpenAI Images API.
3. Review outputs.
4. Move approved images into `/approved`.
5. Move rejected images into `/rejected`.
6. Update the blueprint status after each batch.

## First Batch
Start with:
- PF-001 Productive Fitness Operating System™
- PF-002 Automatic Execution System™
- PF-003 Identity Installation Loop™
- PF-004 90-Day Rewiring Method™
- PF-005 Productive Fitness Scoreboard™
- PF-006 Productivity Killers Ecosystem™
- PF-007 Productivity Drivers Ecosystem™
- PF-008 Personal ROI Dashboard™
- PF-009 Zero Friction Nutrition System™
- PF-010 Smart Supplementation System™
